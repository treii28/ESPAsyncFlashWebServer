########################
## Example readme.txt ##
########################

This is a simple text file!
Nothing much to see here!

You may now go about your day...
