function removeOptions(selectbox) {
    for(var i = selectbox.options.length - 1 ; i >= 0 ; i--)
        selectbox.remove(i);
}
function createOption(val,txt) {
    txt = (typeof(txt) == "undefined") ? val : txt;
    var newOpt = document.createElement('option');
    newOpt.value = val;
    newOpt.innerHTML = txt;
    return newOpt;
}
function setVisibility(obj,vis) {
    //var mainCont = document.getElementById("mainContent");
    vis = (typeof(vis) == 'undefined') ? true : vis;
    if(vis) {
        //mainCont.style.visibility = "hidden";
        obj.style.visibility = "visible";
    } else {
        //mainCont.style.visibility = "hidden";
        obj.style.visibility = "visible";
    }
}

function jsonHelper() {
    // set proper request mode based on browser capabilities
    var xhttp = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");

    // staring point for building on relative urls
    this.baseUrl = baseUrl;

    this.serialize = function( obj ) {
        return '?'+Object.keys(obj).reduce(function(a,k){a.push(k+'='+encodeURIComponent(obj[k]));return a},[]).join('&')
    }

    /**
     *
     * @param {string}        uri  logUri
     * @param {string|object} inp  input parameters
     * @param {object}        obj  object to modify
     * @param {function}      cbf  callback function
     */
    this.getData = function(uri,inp,obj,cbf) {
        setLoading();
        this.getAjax(
            uri, inp,
            function(d) {
                //if(obj.hasOwnProperty('populate') && (typeof(obj.populate) == 'function')) obj.populate(d);
                (typeof cbf == "function") && cbf();
            }
        );
    };

    this.getAjax = function(url,inp,cbf) {
        inp = (typeof(inp) == 'object') ? this.serialize(inp) : inp;
        console.log(inp);
        url = ((typeof(inp) == 'string') && (inp != '')) ? url + inp : url;
        var type = "application/json";
        xhttp.onreadystatechange=function()
        {
            if(this.readyState == 2) {
                type = xhttp.getResponseHeader("Content-Type");
            }
            if (xhttp.readyState==4 && xhttp.status==200)
            {
                var res = false;
                if(type.match(/json/i)) {
                    var rjson = JSON.parse(xhttp.responseText);
                    res = (typeof(rjson) == 'object') ? rjson : xhttp.responseText;
                } else {
                    res = xhttp.responseText;
                }
                (typeof(cbf) == "function") && cbf(res);
            };
        };
        xhttp.open("GET",url,true);
        xhttp.send();
    };
};
