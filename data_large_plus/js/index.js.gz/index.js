
var baseUrl = "";

guestLog.prototype = new jsonHelper();
function guestLog() {
    this.logUri = "/datalog.csv";
    this.addUri = "/signin"
    this.guestEntries = [];
    this.altRowColor;

    this.postEntry = function(uInf) {
        if(!(uInf instanceof guestInfo)) return false;
        var self = this;
        this.getAjax(
            this.addUri, uInf.asJson(),
            function(d) {
                //console.log({data:d});
                self.parseCsvData(d);
            }
        );
    }
    this.getVals = function() {
        var self = this;
        this.getAjax(
            this.logUri, {},
            function(d) {
                //console.log({data:d});
                if(self.parseCsvData(d)) {
                    userInfo.reset();
                    userInfo.populateForm();
                }
            }
        );
    }

    this.parseCsvData = function(data) {
        this.guestEntries = [];
        var lines = data.split(/\r?\n/);
        for(var ln in lines) {
            var entry = this.parseCsvLine(lines[ln]);
            if(entry instanceof guestInfo) {
                this.guestEntries.push(entry);
            }
        }
        if(this.guestEntries.length > 0) {
            this.drawGuestLog();
            return true;
        } else {
            return false;
        }
    };

    this.parseCsvLine = function(line) {
        var fields = line.split("|");
        if(fields.length != 4) return false;
        var newInfo = new guestInfo();
        newInfo.setDate(fields[0]);
        newInfo.setName(fields[1]);
        newInfo.setMemberId(fields[2]);
        newInfo.setComment(fields[3]);
        return newInfo;
    }

    this.drawGuestLog = function() {
        if(!(this.guestEntries.length > 0)) return false; // no entries loaded
        var entries = document.getElementById("guestEntries");
        entries.innerHTML = "";
        this.altRowColor = 0; // reset row color toggle index

        for(var guestId in this.guestEntries) {
            var guestEntryHTML = this.drawEntryRows(parseInt(guestId)+1,this.guestEntries[guestId]);
            if(guestEntryHTML != false) {
                entries.appendChild(guestEntryHTML[0]);
                entries.appendChild(guestEntryHTML[1]);
                this.altRowColor = 1 - this.altRowColor; // toggle the row color index
            }
        }
        return true;
    }

    this.createCellLabel = function(inh) {
        var newCell = document.createElement("th");
        if((typeof(inh) == "string") && (inh != "")) {
            newCell.style.width = "15%";
            newCell.style.textAlign = "right";
            newCell.innerHTML = inh;
            return newCell;
        }
    }
    this.createCell = function(id, inh) {
        var newCell = document.createElement("td");
        if((typeof(id) == "string") && (id != ""))
            newCell.id = id;
        if((typeof(inh) == "string") && (inh != ""))
            newCell.innerHTML = inh;
        return newCell;
    }

    this.drawEntryRows = function(num, info) {
        num = parseInt(num);
        if(!(info instanceof guestInfo) || !(num > 0)) return false;

        var topRow = document.createElement("tr");
        topRow.id = "entry"+num+"row0";
        topRow.className = "row" + this.altRowColor;
        topRow.style.borderLeft = "solid 1px #010101";
        topRow.style.borderRight = "solid 1px #010101";
        topRow.style.borderTop = "solid 1px #010101";

        topRow.appendChild(this.createCellLabel("Date / Time:"));
        topRow.appendChild(this.createCell("datetime"+num, info.getDateString()));
        topRow.appendChild(this.createCellLabel("Name:"));
        topRow.appendChild(this.createCell("guestName"+num, info.name));

        var botRow = document.createElement("tr");
        botRow.id = "entry"+num+"row1";
        botRow.className = "row" + this.altRowColor;
        botRow.style.borderLeft = "solid 1px #010101";
        botRow.style.borderRight = "solid 1px #010101";
        botRow.style.borderBottom = "solid 1px #010101";

        botRow.appendChild(this.createCellLabel("Comment:"));
        commCell = this.createCell("guestComment"+num, info.comment);
        commCell.colSpan = 3;
        botRow.appendChild(commCell);

        return [topRow,botRow];
    }

    this.entryInLog = function(uInf) {
        for(var e in this.guestEntries) {
            if(
                (uInf.name == this.guestEntries[e].name ) &&
                (uInf.memberId == this.guestEntries[e].memberId ) &&
                (uInf.comment == this.guestEntries[e].comment )
            ) return true;
        }
        return false;
    }
}

function guestInfo() {
    this.id;
    this.datetime = new Date();
    this.name;
    this.memberId;
    this.comment;

    this.errors = {};
    this.ticker = false;

    // accessors
    // todo make these check values and possibly work in conjunction with validation for web forms
    this.setDate = function(d) {
        if(d instanceof Date)
            this.datetime = d;
        else
            this.datetime = new Date(d);
    }
    this.getDateString = function(d) {
        d = (d instanceof Date) ? d : this.datetime;
        if(d instanceof Date) {
            var hours = d.getHours();
            var ampm = "AM";
            if(hours > 12) {
                hours = hours - 12;
                ampm = "PM";
            } else if(hours == 0) {
                hours = 12;
            }
            return d.getDate()  + "/" + (d.getMonth()+1) + "/" + d.getFullYear() + " " +
                hours + ":" + d.getMinutes() + ":" + d.getSeconds() + " " + ampm;
        }
    }
    this.setId = function(i) {
        this.id = i;
    };
    this.setName = function(n) {
        this.name = n;
    };
    this.setMemberId = function(mId) {
        this.memberId = mId;
    }
    this.setComment = function(c) {
        this.comment = c;
    }

    this.reset = function() {
        this.datetime = new Date();
        this.name = "";
        this.memberId = null;
        this.comment = "";
    };

    this.populateFromForm = function() {
        this.reset();
        this.setName(document.getElementById('guestName').value);
        this.setMemberId(document.getElementById('memberId').value);
        this.setComment(document.getElementById('guestComment').value);
    };

    this.populateForm = function() {
        this.setDate(new Date());
        document.getElementById('entryDate').innerHTML = this.getDateString();
        document.getElementById('guestName').value    = this.name;
        document.getElementById('memberId').value     = this.memberId;
        document.getElementById('guestComment').value = this.comment;
    }

    // this makes the date/time string update every second with a more current value and displays it on the top of the form
    this.enableDateTicker = function() {
        if(this.ticker == true) return ticker; // ticker is already running
        this.ticker = true;
        this.dateTicker();
    }
    this.dateTicker = function() {
        var self = this;
        if(self.ticker = false) return; // stop looping if ticker property is set to false
        self.setDate(new Date());
        document.getElementById('entryDate').innerHTML = self.getDateString();
        setTimeout( function() { self.dateTicker(); }, 1000 );
    }
    this.isValid = function() {
        this.errors = {};
        this.errors = {};
        if(this.name.length > 31)
            this.errors.name = "too many characters in name field";
        else if(this.name == "")
            this.errors.name = "name cannot be empty";
        if(this.comment.length > 127)
            this.errors.comment = "too many characters in comment field";
        if(this.memberId.length > 7)
            this.errors.memberId = "too many digits in member Id field";
        return(!(this.errors.count > 0));
    }
    this.asJson = function() {
        var reg = /[^\w\d\s\.\,\!\?\-\(\)\"\']/g;
        return {
            name     : this.name.replace(reg,'_'),
            memberId : this.memberId,
            comment  : this.comment.replace(reg,'_'),
            datetime : this.datetime.toLocaleString()
        };
    }

    this.setDate(new Date()); // initialize the date when instantiating a new object
}

function addLogEntry() {
    userInfo.populateFromForm();
    if(userInfo.isValid()) {
        if(userLog.entryInLog(userInfo)) {
            alert('entry already posted!')
            return false;
        } else {
            console.log(userInfo.asJson());
            userLog.postEntry(userInfo);
            return true;
        }
    } else {
        var errTxt;
        for(var e in userInfo.errors) {
            errTxt = e + ": " + userInfo.errors[e] + "\n";
        }
        alert(errTxt);
    }
}

var userInfo, userLog;

function onLoaded() {
    document.getElementById("loadingIndicator").style.visibility = "hidden" ;
    document.getElementById("mainContainer").style.visibility = "visible" ;
    userInfo = new guestInfo();
    userInfo.reset();
    userInfo.populateForm(); // adds date to HTML
    userInfo.enableDateTicker(); // starts second clock
    userLog  = new guestLog();
    // load old guest entries
    userLog.getVals();
    return true;
}