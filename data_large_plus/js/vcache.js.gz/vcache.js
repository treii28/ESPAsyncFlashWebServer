// main listsApp definition
var guestlogApp = angular.module('guestlogApp', []);
// set up the headers to do $http calls with X-Requested-With: XMLHttpRequest to make Zend's isXmlHttpRequest work to detect ajax calls
guestlogApp.config(function($httpProvider) {
    $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
});

guestlogApp.controller(
    'guestlogController',
    function($scope)
    {
        $scope.userData = [];
        $scope.formdata = new guestInfo();

        $scope.getUserData = function()
        {
            Papa.parse("/datalog.csv", {
                download: true,
                complete: function(results) {
                    console.log('csv parsed',results.data);
                    $scope.userData = [];
                    $scope.parseUserData(results.data);
                }
            });
        };
        $scope.parseUserData = function(uDat)
        {
            for(var i in uDat) {
                var r = uDat[i];
                if((r instanceof Array) && (r.length == 4)) {
                    var e = new guestInfo();
                    e.setDate(r[0]);
                    e.setName(r[1]);
                    e.setMemberId(r[2]);
                    e.setComment(r[3]);
                    $scope.userData.push(e);
                }
            }
            $scope.validateForm = function()
            {

            };
            $scope.$apply();
            console.log('parsed userData', $scope.userData);
        };

        // initialize first time
        $scope.getUserData();
    }
);

function guestInfo() {
    this.id;
    this.datetime = new Date();
    this.name;
    this.memberId;
    this.comment;
    this.errors = {};

    // accessors
    // todo make these check values and possibly work in conjunction with validation for web forms
    this.setDate = function(d) {
        if(d instanceof Date)
            this.datetime = d;
        else
            this.datetime = new Date(d);
    }
    this.getDateString = function(d) {
        return this.datetime.toLocaleString();
    }
    this.setId = function(i)
    {
        this.id = i;
    };
    this.setName = function(n)
    {
        this.name = n;
    };
    this.setMemberId = function(mId)
    {
        this.memberId = mId;
    }
    this.setComment = function(c)
    {
        this.comment = c;
    }

    this.isValid = function() {
        this.errors = {};
        this.errors = {};
        if(this.name.length > 31)
            this.errors.name = "too many characters in name field";
        if(this.comment.length > 127)
            this.errors.comment = "too many characters in comment field";
        if(this.memberId.length > 7)
            this.errors.memberId = "too many digits in member Id field";
        return(!(this.errors.count > 0));
    }
    this.asJson = function() {
        return {id:this.id,name:this.name,memberId:this.memberId,comment:this.comment};
    }
}
